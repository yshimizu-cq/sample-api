function test() {
    return "test"
}

module.exports = { test };
